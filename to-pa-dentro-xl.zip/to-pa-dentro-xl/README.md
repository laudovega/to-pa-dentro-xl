# To pa dentro XL

App privada para cocinar con La Monsi: **una jarra, cero dramas, raciones XL**.

- Temperatura máxima: **120 °C**. Nunca 130 °C.
- Recetas por fases: picar, rehogar, cocer, triturar y reposar.
- Despensa híbrida: presencia para lo normal; cantidades para huevos, leche, latas y bricks.
- Lista de compra automática.
- Añade recetas desde `/recetas/nueva` o por `POST /api/recipes`, sin tocar código.

## Local

```bash
npm install
cp .env.example .env
# Edita DATABASE_URL

npx prisma db push
npm run db:seed
npm run dev
```

## Vercel

1. Sube el proyecto a GitHub.
2. En Vercel: **Add New → Project → Import Git Repository**.
3. Conecta una base Postgres desde el Marketplace.
4. Añade `DATABASE_URL` en Environment Variables.
5. Ejecuta:
   ```bash
   npx prisma db push
   npm run db:seed
   ```
6. Despliega.
